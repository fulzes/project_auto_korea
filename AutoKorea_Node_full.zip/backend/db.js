const { Pool } = require('pg');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const DATABASE_URL = process.env.DATABASE_URL || '';
let usePostgres = DATABASE_URL.startsWith('postgres');

let pool = null;
let sqliteDb = null;

async function init() {
  if (usePostgres) {
    pool = new Pool({ connectionString: DATABASE_URL });
    // test
    await pool.query('SELECT 1');
  } else {
    const dbFile = path.join(__dirname, 'autokorea.db');
    sqliteDb = new sqlite3.Database(dbFile);
    await runSql(`CREATE TABLE IF NOT EXISTS cars (id INTEGER PRIMARY KEY AUTOINCREMENT, make TEXT, model TEXT, year INTEGER, price INTEGER, mileage INTEGER, city TEXT, description TEXT);
    CREATE TABLE IF NOT EXISTS showrooms (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, city TEXT, address TEXT, lat TEXT, lon TEXT);
    CREATE TABLE IF NOT EXISTS car_showroom (id INTEGER PRIMARY KEY AUTOINCREMENT, car_id INTEGER, showroom_id INTEGER);
    CREATE TABLE IF NOT EXISTS requests (id INTEGER PRIMARY KEY AUTOINCREMENT, car_id INTEGER, name TEXT, phone TEXT, comment TEXT, status TEXT DEFAULT 'new', created_at TEXT);
    CREATE TABLE IF NOT EXISTS reviews (id INTEGER PRIMARY KEY AUTOINCREMENT, car_id INTEGER, author TEXT, rating INTEGER, text TEXT, created_at TEXT);
    `);
    // insert sample data if empty
    const row = await getSql('SELECT COUNT(*) as c FROM cars');
    if (row && row.c == 0) {
      await runSql("INSERT INTO cars (make, model, year, price, mileage, city, description) VALUES ('Hyundai','Sonata',2018,1200000,50000,'Москва','Надежный седан из Кореи')");
      await runSql("INSERT INTO cars (make, model, year, price, mileage, city, description) VALUES ('Kia','Optima',2017,1100000,65000,'Санкт-Петербург','Комфортный семейный автомобиль')");
      await runSql("INSERT INTO showrooms (name, city, address, lat, lon) VALUES ('AutoKorea Москва','Москва','ул. Примерная, 1','55.75','37.61')");
      await runSql("INSERT INTO showrooms (name, city, address, lat, lon) VALUES ('AutoKorea СПб','Санкт-Петербург','Невский пр., 10','59.93','30.36')");
      await runSql("INSERT INTO car_showroom (car_id, showroom_id) VALUES (1,1)");
      await runSql("INSERT INTO car_showroom (car_id, showroom_id) VALUES (2,2)");
    }
  }
}

function query(text, params) {
  if (usePostgres) {
    return pool.query(text, params);
  } else {
    // wrap sqlite run/all/get as needed
    return new Promise((resolve, reject) => {
      // detect select
      const t = text.trim().toLowerCase();
      if (t.startsWith('select')) {
        sqliteDb.all(text, params, (err, rows) => {
          if (err) reject(err); else resolve({ rows });
        });
      } else {
        sqliteDb.run(text, params, function(err) {
          if (err) reject(err); else resolve({ lastID: this.lastID, changes: this.changes });
        });
      }
    });
  }
}

function runSql(sql) {
  return new Promise((resolve, reject) => {
    sqliteDb.exec(sql, (err) => { if (err) reject(err); else resolve(); });
  });
}

function getSql(sql) {
  return new Promise((resolve, reject) => {
    sqliteDb.get(sql, (err, row) => { if (err) reject(err); else resolve(row); });
  });
}

module.exports = { init, query };
