const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '..', 'frontend')));

// API
app.get('/api/cars', async (req, res) => {
  try {
    const r = await db.query('SELECT * FROM cars');
    const rows = r.rows || r; // pg returns rows, sqlite returns rows in .rows
    res.json(rows);
  } catch (e) { console.error(e); res.status(500).json({error: e.message}); }
});

app.get('/api/cars/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const r = await db.query('SELECT * FROM cars WHERE id = ?', [id]);
    const rows = r.rows || r;
    if (!rows || rows.length === 0) return res.status(404).json({error:'not found'});
    const car = rows[0];
    const cs = await db.query('SELECT showroom_id FROM car_showroom WHERE car_id = ?', [id]);
    const showIds = (cs.rows || cs).map(x=>x.showroom_id);
    let showrooms = [];
    if (showIds.length) {
      // build IN clause
      const placeholders = showIds.map(()=>'?').join(',');
      const sr = await db.query('SELECT * FROM showrooms WHERE id IN ('+placeholders+')', showIds);
      showrooms = sr.rows || sr;
    }
    car.showrooms = showrooms;
    res.json(car);
  } catch (e) { console.error(e); res.status(500).json({error: e.message}); }
});

app.get('/api/requests', async (req,res)=>{
  try {
    const r = await db.query('SELECT * FROM requests ORDER BY created_at DESC');
    res.json(r.rows || r);
  } catch(e){ console.error(e); res.status(500).json({error: e.message}); }
});

app.post('/api/requests', async (req,res)=>{
  try {
    const { car_id, name, phone, comment } = req.body;
    const now = new Date().toISOString();
    const r = await db.query('INSERT INTO requests (car_id,name,phone,comment,status,created_at) VALUES (?,?,?,?,?,?)', [car_id,name,phone,comment,'new',now]);
    res.json({ status:'ok', id: r.lastID || (r.rows && r.rows[0] && r.rows[0].id) });
  } catch(e){ console.error(e); res.status(500).json({error: e.message}); }
});

app.get('/api/reviews', async (req,res)=>{
  try{
    const r = await db.query('SELECT * FROM reviews ORDER BY created_at DESC');
    res.json(r.rows || r);
  } catch(e){ console.error(e); res.status(500).json({error: e.message}); }
});

app.post('/api/reviews', async (req,res)=>{
  try{
    const { car_id, author, rating, text } = req.body;
    const now = new Date().toISOString();
    const r = await db.query('INSERT INTO reviews (car_id,author,rating,text,created_at) VALUES (?,?,?,?,?)', [car_id,author,rating,text,now]);
    res.json({ status:'ok', id: r.lastID });
  } catch(e){ console.error(e); res.status(500).json({error: e.message}); }
});


app.post('/api/requests/:id/status', async (req,res)=>{
  try{
    const id = parseInt(req.params.id);
    const { status } = req.body;
    if(!status) return res.status(400).json({error:'status required'});
    const r = await db.query('UPDATE requests SET status = ? WHERE id = ?', [status, id]);
    res.json({ status:'ok', changes: r.changes || r.rowsAffected || null });
  } catch(e){ console.error(e); res.status(500).json({error: e.message}); }
});

// SPA fallback
app.get('*', (req,res)=>{
  res.sendFile(path.join(__dirname, '..', 'frontend', 'index.html'));
});

(async ()=>{
  try{
    await db.init();
    app.listen(PORT, ()=> console.log(`Server listening on http://localhost:${PORT}`));
  } catch(e){ console.error('Failed to start server:', e); }
})();
