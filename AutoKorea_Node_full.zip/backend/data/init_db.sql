-- Init DB for AutoKorea (PostgreSQL)
CREATE TABLE IF NOT EXISTS cars (
  id serial PRIMARY KEY,
  make varchar(100) NOT NULL,
  model varchar(100) NOT NULL,
  year integer,
  price integer,
  mileage integer,
  city varchar(100),
  description text
);
CREATE TABLE IF NOT EXISTS showrooms (
  id serial PRIMARY KEY,
  name varchar(150),
  city varchar(100),
  address varchar(250),
  lat varchar(50),
  lon varchar(50)
);
CREATE TABLE IF NOT EXISTS car_showroom (
  id serial PRIMARY KEY,
  car_id integer REFERENCES cars(id),
  showroom_id integer REFERENCES showrooms(id)
);
CREATE TABLE IF NOT EXISTS requests (
  id serial PRIMARY KEY,
  car_id integer REFERENCES cars(id),
  name varchar(150),
  phone varchar(50),
  comment text,
  status varchar(50) DEFAULT 'new',
  created_at timestamp default now()
);
CREATE TABLE IF NOT EXISTS reviews (
  id serial PRIMARY KEY,
  car_id integer REFERENCES cars(id),
  author varchar(150),
  rating integer,
  text text,
  created_at timestamp default now()
);
