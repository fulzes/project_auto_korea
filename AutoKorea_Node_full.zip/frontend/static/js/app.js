async function fetchJSON(url, opts){ const r = await fetch(url, opts); return await r.json(); }

async function renderCatalog(){
  const el = document.getElementById('catalog');
  if(!el) return;
  const cars = await fetchJSON('/api/cars');
  el.innerHTML = cars.map(c=>`<div class="card"><h3>${c.make} ${c.model} (${c.year||''})</h3><p>Цена: ${c.price||'—'}</p><p>Пробег: ${c.mileage||'—'}</p><p>Город: ${c.city||'—'}</p><a href="/car.html?id=${c.id}">Подробнее</a></div>`).join('');
}

async function renderCar(){
  const el = document.getElementById('car');
  if(!el) return;
  const params = new URLSearchParams(location.search);
  const id = params.get('id');
  if(!id){ el.innerHTML = '<p>Авто не выбрано</p>'; return; }
  const c = await fetchJSON('/api/cars/'+id);
  el.innerHTML = `<h2>${c.make} ${c.model} (${c.year||''})</h2><p>Цена: ${c.price||'—'}</p><p>Пробег: ${c.mileage||'—'}</p><p>${c.description||''}</p><h4>Доступно в шоурумах:</h4>` + (c.showrooms && c.showrooms.length?('<ul>'+c.showrooms.map(s=>`<li>${s.name} — ${s.city}, ${s.address}</li>`).join('')+'</ul>'):'<p>Не указано</p>');
  const form = document.getElementById('reqForm');
  if(form) form.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const name = document.getElementById('name').value;
    const phone = document.getElementById('phone').value;
    const comment = document.getElementById('comment').value;
    await fetchJSON('/api/requests', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({car_id:id,name,phone,comment})});
    alert('Заявка отправлена');
    form.reset();
  });
}

async function renderReviews(){
  const el = document.getElementById('reviews');
  if(!el) return;
  const list = await fetchJSON('/api/reviews');
  el.innerHTML = list.map(r=>`<div class="card"><strong>${r.author||'Аноним'}</strong> — ${r.rating||0}/5<p>${r.text||''}</p><small>${r.created_at?new Date(r.created_at).toLocaleString():''}</small></div>`).join('');
  const form = document.getElementById('revForm');
  if(form) form.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const author = document.getElementById('author').value;
    const rating = parseInt(document.getElementById('rating').value);
    const text = document.getElementById('text').value;
    await fetchJSON('/api/reviews', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({author,rating,text})});
    alert('Спасибо за отзыв');
    form.reset();
    renderReviews();
  });
}

async function renderShowrooms(){
  const el = document.getElementById('showrooms');
  if(!el) return;
  const cars = await fetchJSON('/api/cars');
  const cities = [...new Set(cars.map(c=>c.city).filter(Boolean))];
  el.innerHTML = '<ul>'+cities.map(c=>`<li>${c}</li>`).join('')+'</ul>';
}

renderCatalog();
renderCar();
renderReviews();
renderShowrooms();
