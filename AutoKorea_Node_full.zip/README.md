AutoKorea — прототип на Node.js + Express

Описание
Проект содержит backend на Node.js (Express) и фронтенд (статические HTML/CSS/JS). По умолчанию backend использует локальную SQLite базу (файл backend/autokorea.db) для быстрого запуска. Для работы с PostgreSQL используйте backend/data/init_db.sql и переменную окружения DATABASE_URL.

Запуск (локально)
1) Откройте терминал и перейдите в backend:
   cd backend
2) Установите зависимости:
   npm install
3) Запустите сервер в режиме разработки (при наличии nodemon):
   npm run dev
   или
   npm start
4) Откройте браузер: http://localhost:5000

Работа с PostgreSQL (DBeaver)
1) Создайте базу данных (например, autokorea) и выполните файл backend/data/init_db.sql
2) Установите переменную окружения DATABASE_URL, например:
   export DATABASE_URL=postgresql://user:password@localhost:5432/autokorea
3) Запустите server: npm start

API
- GET /api/cars
- GET /api/cars/:id
- GET/POST /api/requests
- GET/POST /api/reviews

Дальнейшие шаги
- Добавление панели менеджера, WebSocket чат (socket.io), загрузка медиа и карта с маркерами (Leaflet/Google Maps).


Панель менеджера: /admin.html — список заявок и кнопки управления статусом.